# Vinotes CLI

This is just a readme file for the typer cli, do not delete pls.
